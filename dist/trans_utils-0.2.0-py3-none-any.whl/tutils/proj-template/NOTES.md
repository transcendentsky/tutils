## to do

task manager

multi task pipeline

## Abstract / Brief

## Introduction

## Related Work

## Method

- networks

  - modules
    - reason of using this / what problem to solve
    - why it improve the performance
    - formula
- ablation

### Experiment/Code/scripts

- dataset

  - debug output
- train

  - train: train_v1.py
  - multiple training: train
  -
- test

  - log info
    - many multiple metrics
      - metric(mre), other(sdr)
    - infer-time,
    - dataset
    - script name
    - debug image
