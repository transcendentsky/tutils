"""
Medical/Radiological image quality assessment
"""

