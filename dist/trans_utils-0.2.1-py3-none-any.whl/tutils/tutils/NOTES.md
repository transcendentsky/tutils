
## Dataset Preparation:
- Spacing
- Intensity Range
- Normalization: mean std (self-norm Or Overall)

